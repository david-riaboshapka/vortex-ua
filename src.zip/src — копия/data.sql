SET session_replication_role = replica;

--
-- PostgreSQL database dump
--

-- \restrict 9jZuKbwL5Nu4xfe8uy4Zz0yC3Cv3qRLeiFQD0x6RtU0OHhq3nhU1XNcv3yLiygy

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."chat_messages" ("id", "room_id", "sender_id", "text", "created_at") VALUES
	(1, 'test-room', 'user-1', '123', '2026-01-03 17:03:06.24004+00'),
	(2, 'test-room', 'user-1', 'fewf', '2026-01-03 17:03:20.229891+00'),
	(3, 'test-room', 'user-1', 'rggerg', '2026-01-03 17:04:49.187733+00'),
	(4, 'test-room', 'user-1', 'rgegr', '2026-01-03 17:04:52.756392+00'),
	(5, 'test-room', 'user-1', 'reggreegr', '2026-01-03 17:04:54.544982+00'),
	(6, 'room_2', '2', '4343', '2026-01-03 17:06:19.82144+00'),
	(7, 'room_2', '2', 'ауцауа', '2026-01-03 17:06:22.738669+00'),
	(8, 'room_5', '5', 'уацуаац', '2026-01-03 17:06:29.251409+00'),
	(9, 'room_5', '5', 'grefrg', '2026-01-03 17:14:40.371986+00'),
	(10, 'room_5', 'admin', 'Добрый день', '2026-01-03 17:14:51.372744+00'),
	(11, 'room_5', 'admin', 'rethter', '2026-01-04 22:53:54.77705+00'),
	(12, 'room_2', 'admin', 'пкп', '2026-01-07 12:24:54.107996+00'),
	(13, 'room_5', '5', 'пкп', '2026-01-07 12:27:04.844703+00'),
	(14, 'room_5', 'admin', 'пкпкп', '2026-01-07 12:27:08.019569+00'),
	(15, 'room_5', '2', 'здравствуйте', '2026-01-07 13:16:35.113336+00'),
	(16, 'room_5', '5', 'добрый день', '2026-01-07 13:16:41.770561+00'),
	(17, 'room_5', '2', 'впмпм', '2026-01-07 14:14:37.826243+00'),
	(18, 'room_2', '2', 'РЕК', '2026-01-07 14:20:21.190012+00'),
	(19, 'room_5', '2', 'ПК', '2026-01-07 14:20:25.765125+00'),
	(20, 'room_2', '2', 'курва', '2026-02-20 21:02:00.434998+00'),
	(21, 'room_8', '8', 'Куку', '2026-02-21 18:08:51.657241+00'),
	(22, 'room_8', '8', 'Куку', '2026-02-21 18:08:51.674404+00'),
	(23, 'room_8', '8', 'Куку', '2026-02-21 18:08:51.685881+00'),
	(24, 'room_8', '8', 'Куку', '2026-02-21 18:08:51.698677+00'),
	(25, 'room_8', '8', 'Адазаз', '2026-02-21 18:09:50.325225+00'),
	(26, 'room_8', '8', 'Дкщаща', '2026-02-21 18:09:57.178383+00'),
	(27, 'room_8', '2', 'Ку-ку)', '2026-02-21 18:10:17.10844+00'),
	(28, 'room_8', '8', 'Лалаща', '2026-02-21 18:10:27.809003+00'),
	(29, 'room_8', '2', 'Люблю тебя', '2026-02-21 18:10:40.989804+00'),
	(30, 'room_8', '2', 'Давай ебаться ', '2026-02-21 18:10:52.674454+00'),
	(31, 'room_8', '8', 'А вот ибо да люблю тебя тоже', '2026-02-21 18:10:53.924247+00'),
	(32, 'room_8', '8', 'В туалете?', '2026-02-21 18:10:58.176736+00'),
	(33, 'room_8', '2', 'Прям тут ', '2026-02-21 18:11:02.962355+00'),
	(34, 'room_8', '2', 'Под курточкой друг другу подрочим ', '2026-02-21 18:11:16.264535+00'),
	(35, 'room_8', '8', 'Нас с этой курточкой нахуй выкинут из поезда', '2026-02-21 18:11:43.965481+00'),
	(36, 'room_8', '8', 'Нас с этой курточкой нахуй выкинут из поезда', '2026-02-21 18:11:44.25105+00'),
	(37, 'room_8', '8', 'Нас с этой курточкой нахуй выкинут из поезда', '2026-02-21 18:11:44.322721+00'),
	(38, 'room_8', '8', 'Нас с этой курточкой нахуй выкинут из поезда', '2026-02-21 18:11:44.373879+00'),
	(39, 'room_8', '8', 'А я тебя люблю давидка ', '2026-02-23 18:35:04.665352+00');


--
-- Data for Name: portfolio_projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."portfolio_projects" ("id", "title", "description", "tech_stack", "client_name", "client_feedback", "created_at", "site_url") VALUES
	(34, 'Comms club', 'Creation of an online platform for a professional community of specialists in communications, PR, marketing, media, and related fields. The purpose of the site is to bring specialists together, provide opportunities for sharing experiences, networking, and learning, and promote the development of the professional community through events, meetings, and educational initiatives. Key objectives of the website: To provide information about UK comms club events, meetings, and news. To enable registration and participation in events. To create a point of interaction between community members and the UK comms agency team. To promote the communications sector in Ukraine.', '["HTML CSS WordPress JS PHP"]', 'Alexey', 'f', '2026-02-28 12:22:31.561425', 'https://ukcommsclub.ukcom.com.ua/'),
	(29, 'Старий Хутір', 'Creation of an online platform for the Staryi Khutir ethnic settlement, which allows users to learn about the history and unique architecture of Ukrainian huts from the early 20th century, choose and book accommodation, and find out about cultural traditions, cuisine, and leisure activities. The website aims to promote national heritage and develop the community''s tourism potential through an interactive presentation of residential buildings and services.', '["HTML", "CSS", "WordPress", "JS", "PHP"]', 'Andrey', 'Thanks to the team! The website turned out incredibly atmospheric. You perfectly captured the Ukrainian flavor of the early 20th century while also creating a modern and convenient way to book your cabins. Great job!', '2026-02-28 10:40:02.873632', 'https://staryj-xutir.com.ua/'),
	(30, 'BraveKids', 'Creation of the Brave Kids Ukraine online platform, which supports children and teenagers during wartime, helping them cope with stress, develop, and interact with peers and mentors. The site aims to promote creative games, educational tasks, and video content from renowned Ukrainian and international experts, as well as to encourage children to participate in competitions and communities.', '["HTML CSS JS WP PHP"]', 'Alex', 'Thank you for your professionalism and sensitive approach to such a socially significant project. The interface is intuitively understandable even for the youngest users. You helped bring a complex and important idea to life!', '2026-02-28 11:14:08.850654', 'https://bravekidsukraine.org/'),
	(31, 'Bluship', 'Bluship is a website for an agency specializing in Web3 and NFT community building. The project''s goal is to demonstrate the agency''s expertise in community growth and management, attract clients to partnerships and conversion services in the Web3 space. The website emphasizes a strategic approach, a strong team, and successful case studies to build trust with potential clients.', '["HTML", "CSS", "JS", "React (SPA)", "Vercel"]', 'Maxim', 'Cool design, well-thought-out structure, and excellent performance. The website 100% solves the task of attracting new Web3 partners and clients. We highly recommend this development team!', '2026-02-28 11:15:17.099377', 'https://bluship-three.vercel.app/'),
	(32, 'LikeAuto', '⚙️ Features of the Like AVTO website Home page with a description of the company and its advantages. Catalog of popular auto parts groups. Search for parts by category or keyword. Form for selecting parts by car parameters. Transition to product pages or sections. Contact page with address, phone number, and email. Communication buttons via Viber, WhatsApp, Telegram. Links to social networks (Facebook, Instagram). Built-in Google map with store location. Information block “Why choose us”. Section about the store and operating principles. Feedback form for customers. Responsive layout for mobile devices. Optimization of page loading speed. Visual effects to improve user experience. Block with the store''s working hours. Ability to send a request for spare parts selection. Display of current contacts on all pages. Spam protection for forms (reCAPTCHA or equivalent). Cross-browser compatibility (Chrome, Safari, Firefox).', '["HTML CSS JS WP PHP"]', 'Anton', 'review', '2026-02-28 11:18:47.099836', 'https://likeauto.com.ua/'),
	(33, 'Novoselova', 'Website development for Novoselova&You Studio to showcase creative services in design, branding, animation, and web development. The website displays the portfolio, attracts new clients, and highlights the studio''s unique approach to creating effective designs and brands that sell.', '["HTML CSS WordPress JS PHP"]', 'Ilya', 'f', '2026-02-28 12:22:04.962439', 'https://www.studioandyou.com/');


--
-- Data for Name: portfolio_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."portfolio_images" ("id", "project_id", "image_url", "is_main", "created_at") VALUES
	(30, 34, 'https://github.com/david-riaboshapka/vortex-ua/blob/main/public/images/comms-club.png?raw=true', true, '2026-02-28 12:48:53.432389'),
	(31, 33, 'https://github.com/david-riaboshapka/vortex-ua/blob/main/public/images/Novoselova.png?raw=true', true, '2026-02-28 12:49:19.01141'),
	(32, 32, 'https://github.com/david-riaboshapka/vortex-ua/blob/main/public/images/likeauto.png?raw=true', true, '2026-02-28 12:49:32.825047'),
	(33, 31, 'https://github.com/david-riaboshapka/vortex-ua/blob/main/public/images/Bluship.png?raw=true', true, '2026-02-28 12:49:51.128277'),
	(34, 30, 'https://github.com/david-riaboshapka/vortex-ua/blob/main/public/images/Bravekids.png?raw=true', true, '2026-02-28 12:50:00.311754'),
	(35, 29, 'https://github.com/david-riaboshapka/vortex-ua/blob/main/public/images/%D0%A1%D1%82%D0%B0%D1%80%D0%B8%D0%B9-%D0%A5%D1%83%D1%82%D1%96%D1%80.png?raw=true', true, '2026-02-28 12:50:10.68749');


--
-- Data for Name: portfolio_reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."users" ("id", "email", "password_hash", "role", "first_name", "last_name", "phone", "created_at") VALUES
	(1, 'david.riaboshapka@gmail.com', '$2b$10$1oMnmLIWTCchf2StNcKKxu7h/yJCfsfWlUoZn3DfTtTwMNpBt19zy', 'client', 'Davyd', 'Riaboshapka', NULL, '2025-12-26 13:32:50.61018'),
	(2, 'david123.riaboshapka@gmail.com', '$2b$10$1mGEhCxtHpz7aj1G43Ijs.j.Q/UNkox33E7UhMzIEAnDUrIxghsVy', 'admin', 'Davyd', 'Riaboshapka', '+421 22231231232313', '2025-12-26 13:48:44.924828'),
	(3, 'qwerty@gmail.com', '$2b$10$9PRDUG0KtMItTmSKBNQMw.3kIZT7miNFbVMFCO7E4Ln/37acum.Di', 'client', 'Davyd23', 'Riaboshapka23', '+421 22231231232313', '2026-01-03 01:22:58.060947'),
	(4, 'volodimirletago@gmail.com', '$2b$10$RHnmNbeCvlKhzmOMlDhIEuz.MPSRne.miAAHMrOllwMHVYXDsF5NC', 'admin', '', '', '123456789', '2026-01-03 15:15:18.951502'),
	(5, 'ewfewfwef@gmail.com', '$2b$10$CFmgXLFys9gT5UBeKvT2zeZoHpmERjWH3QUSuV7quzgB12N1eQwJ6', 'client', '', '', '', '2026-01-03 17:04:37.386957'),
	(6, 'test@gmail.com', '$2b$10$9G7bybGKwENb7N/loKeBXugVHngwPseZfkMSyzy8WIuuC.fUvNMJe', 'client', 'testname', 'testname112', '319483248', '2026-02-20 15:25:38.281673'),
	(7, 'ali.cherniavska@gmail.com', '$2b$10$sh9NhJQ2aco1W9E4aDoG4uj8dL3ZJMTVbH7HPsMQ/QZgJH67NNy4e', 'client', 'Твоыл', 'Влуьлу', '20282726', '2026-02-21 17:23:41.733369'),
	(8, 'ali.cherniavska1@gmail.com', '$2b$10$8QFAQZ5R314hwOw9dwMyoOQRPmz44NAn.Zu6gOEd8Pepsdj6Jx7pu', 'client', 'Alicka', 'Dldpdp', '0127282020', '2026-02-21 18:06:22.766126');


--
-- Data for Name: project_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--



--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--



--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--



--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--



--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--



--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--



--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--



--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 1, false);


--
-- Name: chat_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."chat_messages_id_seq"', 39, true);


--
-- Name: portfolio_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."portfolio_images_id_seq"', 35, true);


--
-- Name: portfolio_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."portfolio_projects_id_seq"', 35, true);


--
-- Name: portfolio_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."portfolio_reviews_id_seq"', 34, true);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."posts_id_seq"', 25, true);


--
-- Name: project_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."project_requests_id_seq"', 31, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."users_id_seq"', 8, true);


--
-- PostgreSQL database dump complete
--

-- \unrestrict 9jZuKbwL5Nu4xfe8uy4Zz0yC3Cv3qRLeiFQD0x6RtU0OHhq3nhU1XNcv3yLiygy

RESET ALL;
