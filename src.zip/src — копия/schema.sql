


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "graphql";






CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";






CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";





SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."chat_messages" (
    "id" bigint NOT NULL,
    "room_id" "text" NOT NULL,
    "sender_id" "text" NOT NULL,
    "text" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."chat_messages" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."chat_messages_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."chat_messages_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."chat_messages_id_seq" OWNED BY "public"."chat_messages"."id";



CREATE TABLE IF NOT EXISTS "public"."portfolio_images" (
    "id" integer NOT NULL,
    "project_id" integer,
    "image_url" "text" NOT NULL,
    "is_main" boolean DEFAULT false,
    "created_at" timestamp without time zone DEFAULT "now"()
);


ALTER TABLE "public"."portfolio_images" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."portfolio_images_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."portfolio_images_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."portfolio_images_id_seq" OWNED BY "public"."portfolio_images"."id";



CREATE TABLE IF NOT EXISTS "public"."portfolio_projects" (
    "id" integer NOT NULL,
    "title" "text" NOT NULL,
    "description" "text",
    "tech_stack" "jsonb",
    "client_name" "text",
    "client_feedback" "text",
    "created_at" timestamp without time zone DEFAULT "now"(),
    "site_url" "text"
);


ALTER TABLE "public"."portfolio_projects" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."portfolio_projects_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."portfolio_projects_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."portfolio_projects_id_seq" OWNED BY "public"."portfolio_projects"."id";



CREATE TABLE IF NOT EXISTS "public"."portfolio_reviews" (
    "id" integer NOT NULL,
    "project_id" integer,
    "author_name" "text",
    "rating" integer,
    "text" "text" NOT NULL,
    "is_public" boolean DEFAULT false,
    "created_at" timestamp without time zone DEFAULT "now"(),
    CONSTRAINT "portfolio_reviews_rating_check" CHECK ((("rating" >= 1) AND ("rating" <= 5)))
);


ALTER TABLE "public"."portfolio_reviews" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."portfolio_reviews_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."portfolio_reviews_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."portfolio_reviews_id_seq" OWNED BY "public"."portfolio_reviews"."id";



CREATE TABLE IF NOT EXISTS "public"."posts" (
    "id" integer NOT NULL,
    "title" "text" NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"()
);


ALTER TABLE "public"."posts" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."posts_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."posts_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."posts_id_seq" OWNED BY "public"."posts"."id";



CREATE TABLE IF NOT EXISTS "public"."project_requests" (
    "id" integer NOT NULL,
    "user_id" integer NOT NULL,
    "title" "text" NOT NULL,
    "description" "text" NOT NULL,
    "budget" "text",
    "status" "text" DEFAULT 'new'::"text",
    "created_at" timestamp without time zone DEFAULT "now"()
);


ALTER TABLE "public"."project_requests" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."project_requests_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."project_requests_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."project_requests_id_seq" OWNED BY "public"."project_requests"."id";



CREATE TABLE IF NOT EXISTS "public"."users" (
    "id" integer NOT NULL,
    "email" "text" NOT NULL,
    "password_hash" "text" NOT NULL,
    "role" "text" NOT NULL,
    "first_name" "text" NOT NULL,
    "last_name" "text" NOT NULL,
    "phone" "text",
    "created_at" timestamp without time zone DEFAULT "now"(),
    CONSTRAINT "users_role_check" CHECK (("role" = ANY (ARRAY['admin'::"text", 'client'::"text"])))
);


ALTER TABLE "public"."users" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."users_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."users_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."users_id_seq" OWNED BY "public"."users"."id";



ALTER TABLE ONLY "public"."chat_messages" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."chat_messages_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."portfolio_images" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."portfolio_images_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."portfolio_projects" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."portfolio_projects_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."portfolio_reviews" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."portfolio_reviews_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."posts" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."posts_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."project_requests" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."project_requests_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."users" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."users_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."chat_messages"
    ADD CONSTRAINT "chat_messages_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."portfolio_images"
    ADD CONSTRAINT "portfolio_images_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."portfolio_projects"
    ADD CONSTRAINT "portfolio_projects_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."portfolio_reviews"
    ADD CONSTRAINT "portfolio_reviews_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."posts"
    ADD CONSTRAINT "posts_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."project_requests"
    ADD CONSTRAINT "project_requests_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_email_key" UNIQUE ("email");



ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."portfolio_images"
    ADD CONSTRAINT "portfolio_images_project_id_fkey" FOREIGN KEY ("project_id") REFERENCES "public"."portfolio_projects"("id");



ALTER TABLE ONLY "public"."portfolio_reviews"
    ADD CONSTRAINT "portfolio_reviews_project_id_fkey" FOREIGN KEY ("project_id") REFERENCES "public"."portfolio_projects"("id");



ALTER TABLE ONLY "public"."project_requests"
    ADD CONSTRAINT "project_requests_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id");





ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";






ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."chat_messages";



GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";








































































































































































GRANT ALL ON TABLE "public"."chat_messages" TO "anon";
GRANT ALL ON TABLE "public"."chat_messages" TO "authenticated";
GRANT ALL ON TABLE "public"."chat_messages" TO "service_role";



GRANT ALL ON SEQUENCE "public"."chat_messages_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."chat_messages_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."chat_messages_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."portfolio_images" TO "anon";
GRANT ALL ON TABLE "public"."portfolio_images" TO "authenticated";
GRANT ALL ON TABLE "public"."portfolio_images" TO "service_role";



GRANT ALL ON SEQUENCE "public"."portfolio_images_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."portfolio_images_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."portfolio_images_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."portfolio_projects" TO "anon";
GRANT ALL ON TABLE "public"."portfolio_projects" TO "authenticated";
GRANT ALL ON TABLE "public"."portfolio_projects" TO "service_role";



GRANT ALL ON SEQUENCE "public"."portfolio_projects_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."portfolio_projects_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."portfolio_projects_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."portfolio_reviews" TO "anon";
GRANT ALL ON TABLE "public"."portfolio_reviews" TO "authenticated";
GRANT ALL ON TABLE "public"."portfolio_reviews" TO "service_role";



GRANT ALL ON SEQUENCE "public"."portfolio_reviews_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."portfolio_reviews_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."portfolio_reviews_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."posts" TO "anon";
GRANT ALL ON TABLE "public"."posts" TO "authenticated";
GRANT ALL ON TABLE "public"."posts" TO "service_role";



GRANT ALL ON SEQUENCE "public"."posts_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."posts_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."posts_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."project_requests" TO "anon";
GRANT ALL ON TABLE "public"."project_requests" TO "authenticated";
GRANT ALL ON TABLE "public"."project_requests" TO "service_role";



GRANT ALL ON SEQUENCE "public"."project_requests_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."project_requests_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."project_requests_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."users" TO "anon";
GRANT ALL ON TABLE "public"."users" TO "authenticated";
GRANT ALL ON TABLE "public"."users" TO "service_role";



GRANT ALL ON SEQUENCE "public"."users_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."users_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."users_id_seq" TO "service_role";









ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";































